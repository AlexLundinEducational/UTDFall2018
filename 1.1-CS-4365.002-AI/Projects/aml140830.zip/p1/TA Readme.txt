s1.py 
	is the script driver for the search
	edit the inputFileName variable to change the name of the input file for reading
	
Steps to execute program
	open windows command line
	navigate to current directory of the project files	
	call by executing the following command in window command line
	python s1.py

40 second video of working program
	https://knowledge.autodesk.com/community/screencast/f257da60-0bdd-4d8a-a253-184183e19cd3