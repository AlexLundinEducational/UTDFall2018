"""Search (Chapters 3-4)

The way to use this code is to subclass Problem to create a class of problems,
then create problem instances and solve them with calls to the various search
functions."""

from utils import (
    is_in, argmin, argmax, argmax_random_tie, probability, weighted_sampler,
    memoize, print_table, open_data, PriorityQueue, name,
    distance, vector_add
)

from collections import defaultdict, deque
import math
import random
import sys
import bisect
from operator import itemgetter


# All edits are marked with a comment started with my name
# code from http://aima.cs.berkeley.edu/code.html
	   
# Alex Lundin
# Added just for you :-)
# prints action sequence from a certain node
def printMoves(goalNode):
    sequenceOfActions = goalNode.solution()
    print (sequenceOfActions)
    return 0
	
# Alex Lundin
# accepts node as arguments
# Uses node class to traverse the path from initial state to goal node
# Prints 3 nodes per line
# Then starts a new line
def printBoard(goalNode):
    path = goalNode.path()
    print("\n")	
    for node in path:
        i = 0
        
        for tile in node.state:
            # on the 3rd node printed
			# reset the counter i and print a newline
            if i > 2:
                print("\n")
                i = 0
            sys.stdout.write(str(tile))
			# print a space between nodes
            sys.stdout.write(" ")
            sys.stdout.flush()
            i += 1
		# add two newlines between board prints
        print("\n")
        print("\n")	





	
infinity = float('inf')

# ______________________________________________________________________________


class Problem(object):

    """The abstract class for a formal problem. You should subclass
    this and implement the methods actions and result, and possibly
    __init__, goal_test, and path_cost. Then you will create instances
    of your subclass and solve them with the various search functions."""

    def __init__(self, initial, goal=None):
        """The constructor specifies the initial state, and possibly a goal
        state, if there is a unique goal. Your subclass's constructor can add
        other arguments."""
        self.initial = initial
        self.goal = goal

    def actions(self, state):
        """Return the actions that can be executed in the given
        state. The result would typically be a list, but if there are
        many actions, consider yielding them one at a time in an
        iterator, rather than building them all at once."""
        raise NotImplementedError

    def result(self, state, action):
        """Return the state that results from executing the given
        action in the given state. The action must be one of
        self.actions(state)."""
        raise NotImplementedError

    def goal_test(self, state):
        """Return True if the state is a goal. The default method compares the
        state to self.goal or checks for state in self.goal if it is a
        list, as specified in the constructor. Override this method if
        checking against a single self.goal is not enough."""
        if isinstance(self.goal, list):
            return is_in(state, self.goal)
        else:
            return state == self.goal

    def path_cost(self, c, state1, action, state2):
        """Return the cost of a solution path that arrives at state2 from
        state1 via action, assuming cost c to get up to state1. If the problem
        is such that the path doesn't matter, this function will only look at
        state2.  If the path does matter, it will consider c and maybe state1
        and action. The default method costs 1 for every step in the path."""
        return c + 1

    def value(self, state):
        """For optimization problems, each state has a value.  Hill-climbing
        and related algorithms try to maximize this value."""
        raise NotImplementedError
# ______________________________________________________________________________


class Node:

    """A node in a search tree. Contains a pointer to the parent (the node
    that this is a successor of) and to the actual state for this node. Note
    that if a state is arrived at by two paths, then there are two nodes with
    the same state.  Also includes the action that got us to this state, and
    the total path_cost (also known as g) to reach the node.  Other functions
    may add an f and h value; see best_first_graph_search and astar_search for
    an explanation of how the f and h values are handled. You will not need to
    subclass this class."""

    def __init__(self, state, parent=None, action=None, path_cost=0):
        """Create a search tree Node, derived from a parent by an action."""
        self.state = state
        self.parent = parent
        self.action = action
        self.path_cost = path_cost
        self.depth = 0
        if parent:
            self.depth = parent.depth + 1

    def __repr__(self):
        return "<Node {}>".format(self.state)

    def __lt__(self, node):
        return self.state < node.state

	# Alex Lundin
	# Edited node expansion to not allow anything from the path Home to be expanded
	# This ensures the algorithm can not undo good moves it made it the past
	# This reduces the number of repeated states
    def expand(self, problem):
        """List the nodes reachable in one step from this node."""
        reachAbleNodes = list()

		# don't add any nodes that are on the path home to the set of reachable nodes
        pathHome = self.path()
        for action in problem.actions(self.state):
            tempNode = self.child_node(problem, action)
            addIt = 1
            for p1 in pathHome:
               if  tempNode == p1:
                  addIt = 0
            if addIt == 1:
               reachAbleNodes.append(tempNode)
        return reachAbleNodes

    def child_node(self, problem, action):
        """[Figure 3.10]"""
        next_state = problem.result(self.state, action)
        next_node = Node(next_state, self, action,
                    problem.path_cost(self.path_cost, self.state,
                                      action, next_state))
        return next_node
    
    def solution(self):
        """Return the sequence of actions to go from the root to this node."""
        return [node.action for node in self.path()[1:]]

    def path(self):
        """Return a list of nodes forming the path from the root to this node."""
        node, path_back = self, []
        while node:
            path_back.append(node)
            node = node.parent
        return list(reversed(path_back))

    def parent_node(self):
        return node.parent
    # We want for a queue of nodes in breadth_first_graph_search or
    # astar_search to have no duplicated states, so we treat nodes
    # with the same state as equal. [Problem: this may not be what you
    # want in other contexts.]

    def __eq__(self, other):
        return isinstance(other, Node) and self.state == other.state

    def __hash__(self):
        return hash(self.state)

# ______________________________________________________________________________



# ______________________________________________________________________________
# Uninformed Search algorithms



class EightPuzzle(Problem):

    """ The problem of sliding tiles numbered from 1 to 8 on a 3x3 board,
    where one of the squares is a blank. A state is represented as a 3x3 list,
    where element at index i,j represents the tile number (0 if it's an empty square) """
	# Alex Lundin
	# Edited order of nodes for goal
    def __init__(self, initial, goal=(0, 1, 2, 3, 4, 5, 6, 7, 8)):
        """ Define goal state and initialize a problem """

        self.goal = goal
        Problem.__init__(self, initial, goal)
    
    def find_blank_square(self, state):
        """Return the index of the blank square in a given state"""

        return state.index(0)
    
    def actions(self, state):
        """ Return the actions that can be executed in the given state.
        The result would be a list, since there are only four possible actions
        in any given state of the environment """
        
        possible_actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']       
        index_blank_square = self.find_blank_square(state)

        if index_blank_square % 3 == 0:
            possible_actions.remove('LEFT')
        if index_blank_square < 3:
            possible_actions.remove('UP')
        if index_blank_square % 3 == 2:
            possible_actions.remove('RIGHT')
        if index_blank_square > 5:
            possible_actions.remove('DOWN')

        return possible_actions

    def result(self, state, action):
        """ Given state and action, return a new state that is the result of the action.
        Action is assumed to be a valid action in the state """

        # blank is the index of the blank square
        blank = self.find_blank_square(state)
        new_state = list(state)

        delta = {'UP':-3, 'DOWN':3, 'LEFT':-1, 'RIGHT':1}
        neighbor = blank + delta[action]
        new_state[blank], new_state[neighbor] = new_state[neighbor], new_state[blank]

        return tuple(new_state)

    def goal_test(self, state):
        """ Given a state, return True if state is a goal state or False, otherwise """

        return state == self.goal

    def check_solvability(self, state):
        """ Checks if the given state is solvable """

        inversion = 0
        for i in range(len(state)):
            for j in range(i, len(state)):
                if state[i] > state[j] != 0:
                    inversion += 1
        
        return inversion % 2 == 0
    
    def h(self, node):
        """ Return the heuristic value for a given state. Default heuristic function used is 
        h(n) = number of misplaced tiles """

        return sum(s != g for (s, g) in zip(node.state, self.goal))

# ______________________________________________________________________________





def recursive_best_first_search(problem, h):
    """[Figure 3.26]"""


	
    def RBFS(problem, node, flimit):	
	
        if problem.goal_test(node.state):
            return node, 0   # (The second value is immaterial)
			
		# Alex Lundin
		# Edited expand method in node class
		# now expansion does NOT include any nodes that are already on the solution path of the current node
		# this reduces repeated states
        successors = node.expand(problem)
        if len(successors) == 0:
            return None, infinity
			
        for s in successors:
               s.f = max(s.path_cost + h(s), node.f)
 
        while True:
            # Order by lowest f value
            successors.sort(key=lambda x: x.f)
            best = successors[0]
			# if the best avaiable node is worse than the flimit
            if best.f > flimit:
                return None, best.f
			# if there is atleast one more node to expand
            if len(successors) > 1:
				# set the alternative value
                alternative = successors[1].f
			# else there are no more nodes to expand
            else:
				# set alternative to infinity
                alternative = infinity
			# when program makes it to here, then recur
			   
            result, best.f = RBFS(problem, best, min(flimit, alternative))
            if result is not None:
                return result, best.f
	
    node = Node(problem.initial)
    node.f = h(node)
    result, bestf = RBFS(problem, node, infinity)
	# Alex Lundin
	# Added printers when solution is found
    # print("\nSolution Found")
    # printMoves(result)
    # print("\nMove Sequence")
    printBoard(result)
    return result

