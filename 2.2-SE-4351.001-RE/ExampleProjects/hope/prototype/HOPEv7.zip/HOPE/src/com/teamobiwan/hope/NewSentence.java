package com.teamobiwan.hope;

import java.util.Locale;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

public class NewSentence extends Activity implements OnInitListener {
	private static final String TAG = "HOPE";
	private TextToSpeech mTts;
	private EditText textbox;
	private Spinner spinner;
	private ArrayAdapter<CharSequence> adapter;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newsentence);
        
        adapter = new ArrayAdapter<CharSequence>(this, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        
        //Some default sentences
        adapter.add("Get off my lawn you darn kids!");
        adapter.add("When I was your age, I had to walk 10 miles in the snow");
        adapter.add("Woohoo, time for my meds!");
        adapter.add("Let's go to Luby's for lunch.");
        
        spinner = (Spinner)findViewById(R.id.recentsentenceSpinner);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new SpinnerListener());
        
        textbox = (EditText)findViewById(R.id.newsentenceTextView);
        
        Button saveButton = (Button)findViewById(R.id.saveButton);
        Button speakButton = (Button)findViewById(R.id.speakButton);
        
        saveButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	CharSequence newText = "" + textbox.getText().toString();
                adapter.add(newText);
            }
        });
        
        speakButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mTts.speak(textbox.getText().toString(), TextToSpeech.QUEUE_FLUSH, null);
            }
        });
        
        mTts = new TextToSpeech(this, this);
    }
    
    public class SpinnerListener implements OnItemSelectedListener {    
    	public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {      
    		textbox.setText(parent.getItemAtPosition(pos).toString());    
    	}    
    	
    	public void onNothingSelected(AdapterView<?> parent) {     
    		textbox.setText("");
    	}
    }
    
    @Override
    public void onDestroy() {
        // Don't forget to shutdown!
        if (mTts != null) {
            mTts.stop();
            mTts.shutdown();
        }

        super.onDestroy();
    }
    
    // Implements TextToSpeech.OnInitListener.
    public void onInit(int status) {
        // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
        if (status == TextToSpeech.SUCCESS) {
            // Set preferred language to US english.
            // Note that a language may not be available, and the result will indicate this.
            int result = mTts.setLanguage(Locale.US);
            // Try this someday for some interesting results.
            // int result mTts.setLanguage(Locale.FRANCE);
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
               // Lanuage data is missing or the language is not supported.
                Log.e(TAG, "Language is not available.");
            }
        } else {
            // Initialization failed.
            Log.e(TAG, "Could not initialize TextToSpeech.");
        }
    }
}
