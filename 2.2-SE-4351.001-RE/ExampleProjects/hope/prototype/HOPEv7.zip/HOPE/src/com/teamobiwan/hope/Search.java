package com.teamobiwan.hope;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Search extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);
        
        Button submitButton = (Button)findViewById(R.id.submitButton);
        
        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	Toast.makeText(Search.this, "Not yet implemented", Toast.LENGTH_SHORT).show(); 
            }
        });
    }
}
