package com.teamobiwan.hope;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapter4 extends BaseAdapter {    
	private Integer[] mImageIds;
	private Context mContext;    
	
	public ImageAdapter4(Integer[] images, Context c) {   
		mImageIds = images;
		mContext = c;    
	}    
	
	public int getCount() {        
		return mImageIds.length;    
	}    
	
	public Object getItem(int position) {        
		return null;    
	}    
	
	public long getItemId(int position) {        
		return 0;    
	}    
	
	// create a new ImageView for each item referenced by the Adapter    
	public View getView(int position, View convertView, ViewGroup parent) {        
		ImageView imageView;        
		if (convertView == null) {  
			// if it's not recycled, initialize some attributes            
			imageView = new ImageView(mContext);            
			imageView.setLayoutParams(new GridView.LayoutParams(150, 200));            
			imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);            
			imageView.setPadding(8, 8, 8, 8);        
		} else {            
			imageView = (ImageView) convertView;        
		}        
		imageView.setImageResource(mImageIds[position]);        
		return imageView;    
	}    
}