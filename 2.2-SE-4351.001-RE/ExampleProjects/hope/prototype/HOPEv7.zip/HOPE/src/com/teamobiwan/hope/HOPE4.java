package com.teamobiwan.hope;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class HOPE4 extends Activity {
	private static final int VIEW_16 = Menu.FIRST;
	
	// references to our images    
	private Integer[] mThumbIds = {            
			R.drawable.search, 	R.drawable.talk,
			R.drawable.recent, R.drawable.emergency
	};
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        GridView gridview = (GridView) findViewById(R.id.gridview);    
        gridview.setAdapter(new ImageAdapter4(mThumbIds, this));    
        gridview.setOnItemClickListener(new OnItemClickListener() {        
        	public void onItemClick(AdapterView<?> parent, View v, int position, long id) {   
        		Intent i = null;
        		switch (position) {
        			case 0:
        				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Search");
        				break;
        				
        			case 1:
        				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Talk");
        				break;
        				
        			case 2:
        				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Recent");
        				break;
        				
        			case 3:
        				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Emergency");
        				break;	
        				
        			default:
        				Toast.makeText(HOPE4.this, "Not yet implemented", Toast.LENGTH_SHORT).show(); 
        		}     
        		if (i != null)
        			startActivityForResult(i, RESULT_OK);
        	}    
        });
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	boolean result = super.onCreateOptionsMenu(menu);
    	menu.add(0, VIEW_16, 0, "16 Icon View");
    	return result;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
    		case VIEW_16:
    			Intent i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.HOPE");
    			startActivityForResult(i, RESULT_OK);
    			return true;
    	}
    	
    	return super.onOptionsItemSelected(item);
    }
}