package com.teamobiwan.hope;

import java.util.Locale;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.AdapterView.OnItemClickListener;

public class Household16 extends Activity implements OnInitListener {
	private static final String TAG = "HOPE";
	private TextToSpeech mTts;
	
	// references to our images    
	private Integer[] mThumbIds = {            
			R.drawable.lightson16, R.drawable.lightsoff16, R.drawable.tempup16, R.drawable.tempdown16, 
	};
	
	// speakable strings
	private String[] mStrings = {
			"Please turn the lights on.", 
			"Please turn the lights off.", 
			"Please raise the temperature.", 
			"Please lower the temperature."
	};
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.household16);
        
        GridView gridview = (GridView) findViewById(R.id.gridview);    
        gridview.setAdapter(new ImageAdapter16(mThumbIds, this));    
        gridview.setOnItemClickListener(new OnItemClickListener() {        
        	public void onItemClick(AdapterView<?> parent, View v, int position, long id) {   
        		mTts.speak(mStrings[position], TextToSpeech.QUEUE_FLUSH, null);
        	}
        });
        
        mTts = new TextToSpeech(this, this);
    }
    
    @Override
    public void onDestroy() {
        // Don't forget to shutdown!
        if (mTts != null) {
            mTts.stop();
            mTts.shutdown();
        }

        super.onDestroy();
    }
    
    // Implements TextToSpeech.OnInitListener.
    public void onInit(int status) {
        // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
        if (status == TextToSpeech.SUCCESS) {
            // Set preferred language to US english.
            // Note that a language may not be available, and the result will indicate this.
            int result = mTts.setLanguage(Locale.US);
            // Try this someday for some interesting results.
            // int result mTts.setLanguage(Locale.FRANCE);
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
               // Lanuage data is missing or the language is not supported.
                Log.e(TAG, "Language is not available.");
            }
        } else {
            // Initialization failed.
            Log.e(TAG, "Could not initialize TextToSpeech.");
        }
    }
}