package com.teamobiwan.hope;

import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class HOPE extends Activity implements OnInitListener {
	private static final int VIEW_4 = Menu.FIRST;
	private static final String TAG = "HOPE";
	private TextToSpeech mTts;
		
	// references to our images    
	private Integer[] mThumbIds = {            
		R.drawable.tasks16, R.drawable.food16, R.drawable.places16, R.drawable.restroom16, 
		R.drawable.household16, R.drawable.outdoors16, R.drawable.people16, R.drawable.health16, 
		R.drawable.greetings16, R.drawable.responses16, R.drawable.listen16, R.drawable.newsentence16, 
		R.drawable.recent16, R.drawable.help16, R.drawable.search16, R.drawable.emergency16
	};
		
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.hope16);
	        
	    GridView gridview = (GridView) findViewById(R.id.gridview);    
	    gridview.setAdapter(new ImageAdapter16(mThumbIds, this));    
	    gridview.setOnItemClickListener(new OnItemClickListener() {        
	    	public void onItemClick(AdapterView<?> parent, View v, int position, long id) {   
	        	Intent i = null;
	        	switch (position) {
	        		case 1:
	        			i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Food16");
	        			break;
	        		
	        		case 3:
	        			mTts.speak("I need to use the restroom.", TextToSpeech.QUEUE_FLUSH, null);
	        			break;
	        				
	        		case 4:
	       				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Household16");
	       				break;
	        		
	       			case 6:
	       				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.People");
	       				break;
	       				
	       			case 8:
	       				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Greetings16");
	       				break;
	        		
	       			case 9:
	       				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Responses16");
	       				break;	
	       				
	       			case 10:
	       				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Listen");
	       				break;
	        				
	       			case 11:
	        			i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.NewSentence");
	       				break;
	        		
	       			case 12:
	       				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Recent16");
	    				break;
	    					
	        		case 14:
	        			i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Search");
	        			break;
	        				
	        		case 15:
	        			i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Emergency");
	        			break;	
	        			
	        		default:
	        			Toast.makeText(HOPE.this, "Not yet implemented", Toast.LENGTH_SHORT).show(); 
	        	}     
	       		if (i != null)
	       			startActivityForResult(i, RESULT_OK);
	       	}    
	    });
	        
	    mTts = new TextToSpeech(this, this);
	}
	    
	@Override
	public void onDestroy() {
	    // Don't forget to shutdown!
	    if (mTts != null) {
	        mTts.stop();
	        mTts.shutdown();
	    }

	    super.onDestroy();
	}
	    
	// Implements TextToSpeech.OnInitListener.
	public void onInit(int status) {
	    // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR.
	    if (status == TextToSpeech.SUCCESS) {
	        // Set preferred language to US english.
	        // Note that a language may not be available, and the result will indicate this.
	        int result = mTts.setLanguage(Locale.US);
	        // Try this someday for some interesting results.
	        // int result mTts.setLanguage(Locale.FRANCE);
	        if (result == TextToSpeech.LANG_MISSING_DATA ||
	            result == TextToSpeech.LANG_NOT_SUPPORTED) {
	           // Lanuage data is missing or the language is not supported.
	            Log.e(TAG, "Language is not available.");
	        }
	    } else {
	        // Initialization failed.
	        Log.e(TAG, "Could not initialize TextToSpeech.");
	    }
	}
	    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	    boolean result = super.onCreateOptionsMenu(menu);
	    menu.add(0, VIEW_4, 0, "4 Icon View");
	    return result;
	}
	    
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
	    	case VIEW_4:
	    		Intent i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.HOPE4");
	    		startActivityForResult(i, RESULT_OK);
	    		return true;
	    }	
	    return super.onOptionsItemSelected(item);
	}
}
