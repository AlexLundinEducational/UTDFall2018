package com.teamobiwan.hope;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class Talk2 extends Activity {
	// references to our images    
	private Integer[] mThumbIds = {            
			R.drawable.newsentence, 	R.drawable.listen,
			R.drawable.back, 			R.drawable.more
	};
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.talk2);
        
        GridView gridview = (GridView) findViewById(R.id.gridview);    
        gridview.setAdapter(new ImageAdapter4(mThumbIds, this));    
        gridview.setOnItemClickListener(new OnItemClickListener() {        
        	public void onItemClick(AdapterView<?> parent, View v, int position, long id) {   
        		Intent i = null;
        		switch (position) {
        			case 0:
        				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.NewSentence");
        				break;
        				
        			case 1:
        				i = new Intent().setClassName("com.teamobiwan.hope", "com.teamobiwan.hope.Listen");
        				break;
        				
        			case 2:
        				setResult(RESULT_OK);
        				finish();
        				break;
        				
        			default:
        				Toast.makeText(Talk2.this, "Not yet implemented", Toast.LENGTH_SHORT).show(); 
        		}     
        		if (i != null)
        			startActivityForResult(i, RESULT_OK);
        	}    
        });  
    }
}
