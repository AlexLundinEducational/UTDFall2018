package com.teamobiwan.hope;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;

public class Listen extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listen);	
	
        EditText textbox = (EditText)findViewById(R.id.listenTextView);
        textbox.setText("All work and no play makes Jack a dull boy.");
        
        ImageView micButton = (ImageView)findViewById(R.id.microphoneButton);
        micButton.setClickable(true);
    }
}
