


#include "includeFile.h"
#include <stdio.h>

// Hello world, with include file
int main()
{
   // printf() displays the string inside quotation
   printf("\nHello, World!");
   printf("\n.");
   return 0;
}
